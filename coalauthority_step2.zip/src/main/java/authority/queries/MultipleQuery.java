package authority.queries;

import authority.data.Boundary;
import authority.data.Entry;

import java.util.Collection;
import java.util.HashSet;
import java.util.stream.Collectors;

public class MultipleQuery implements Query {

    private Collection<Boundary> boundaries = new HashSet<>();

    public MultipleQuery boundary(Boundary boundary) {
        boundaries.add(boundary);
        return this;
    }

    @Override
    public Collection<Entry> apply(Collection<Entry> entries) {
        if (boundaries == null || boundaries.isEmpty()) {
            return entries;
        }

        return boundaries.stream()
                .map(b -> applyQuery(entries, b))
                .flatMap(e -> e.stream())
                .collect(Collectors.toSet());
    }
}
