package authority.queries;

import authority.data.Boundary;
import authority.data.Entry;

import java.util.Collection;
import java.util.stream.Collectors;

public class SingleQuery implements Query {
    private final Boundary boundary;

    public SingleQuery(Boundary boundary) {
        this.boundary = boundary;
    }

    public Boundary getBoundary() {
        return boundary;
    }

    @Override
    public Collection<Entry> apply(Collection<Entry> entries) {
        if (boundary == null) {
            return entries;
        }
        return entries.stream()
                .filter(e -> entryWithInBoundary(e, getBoundary()))
                .collect(Collectors.toSet());
    }

    private boolean entryWithInBoundary(Entry e, Boundary boundary) {
        int latitude = e.getCoordinate().getLatitude();
        int longitude = e.getCoordinate().getLongitude();
        return
                latitude >= boundary.getXLow() &&
                        latitude <= boundary.getXHigh() &&
                        longitude >= boundary.getYLow() &&
                        longitude <= boundary.getYHigh();
    }
}
