package authority.queries;

import authority.data.Entry;

import java.util.Collection;

public interface Query {
    Collection<Entry> apply(Collection<Entry> entries);
}
